# Any config constants or utility functions
PLAYLISTS_DIR = "playlists"